const express = require("express");
const mysql = require("mysql");
const cors = require("cors");
const bcrypt = require("bcryptjs");
// const fileUpload = require('express-fileupload');
const app = express();


app.use(express.json());

// for web page http
app.use(cors());

// app.use(fileUpload());

//mysql connection
const con = mysql.createPool({
  user: "root",
  host: "localhost",
  password: "root",
  database: "world_line"
})

const ROLES = {
  USER: 2,
  ADMIN: 1,
};

app.post('/page/signup', (req, res) => {

    const emp_name = req.body.emp_name;
    console.log(emp_name);
    const emp_code = req.body.emp_code;
    console.log(emp_code)
    const passw = req.body.passw;
    console.log(passw)
    const cpassw = req.body.cpassw;
    console.log(cpassw)
    const role = ROLES.USER;
  
    // Generate a salt and hash the passwords into database
    bcrypt.genSalt(10, (err, salt) => {
      bcrypt.hash(passw.toString(), salt, (err, hashPassw) => {
        if (err) throw err;
  
        bcrypt.hash(cpassw.toString(), salt, (err, hashCpassw) => {
          if (err) throw err;
  
          // Mysql query for database
          const sql = "INSERT INTO login (Employee_Name, Employee_Code, Password, Cf_Password, Role) VALUES (?, ?, ?, ?,2)";
          con.query(sql, [req.body.emp_name, req.body.emp_code, hashPassw, hashCpassw, role], (err, result) => {
            if (err) {
              if (err.code === 'ER_DUP_ENTRY') {
                return res.json({ message: "Duplicate entry detected" }); // Send duplicate entry message
              }
              console.error(err);
              return res.json({ message: "Signup failed" }); // Send general failure message
            }
            console.log('Signup success')
            return res.json({ message: "Signup Success" });  // Send Signup success message
          });
        });
      });
    });
  });
  
  
  // for login page value inserting into database 
  app.post("/", (req, res) => {
  
    const username1 = req.body.emp_code1;
    console.log(username1);
    const passw1 = req.body.passw1;
    console.log(passw1);
  
    // Mysql query for database
    const sql1 = "SELECT * FROM login WHERE Employee_Code = ?";
  
    con.query(sql1, [username1], (err, rows) => {
      if (err) {
        console.error(err);
        return res.json({ message: "Error querying database" });
      }
  
      if (rows.length === 0) {
        return res.json({ message: "User not found" });
      }
  
      const storedHash = rows[0].Password;
      console.log(storedHash);
      const role = rows[0].Role;
      console.log(role);
      console.log(ROLES.ADMIN);
      console.log(ROLES.USER);
  
  
      // for reverse hash the passwords from database
      bcrypt.compare(passw1, storedHash, (err, result) => {
        if (err) {
          console.error(err);
          return res.json({ message: "Error comparing passwords" });
        }
  
        if (result) {
          console.log('Login success');
  
          console.log(role);
          // console.log(ROLES.USER);
          if (role == ROLES.ADMIN) {
            console.log(rows[0]);
            return res.json({ message: "Login success", role: "admin", userInfo: rows[0] });
          } else if (role == ROLES.USER) {
            console.log(rows[0]);
            return res.json({ message: "Login success", role: "user", userInfo: rows[0] });
            // return res.json({ message: "Login success", userInfo: rows[0] });
          }
        } else {
          return res.json({ message: "Wrong password" });
        }
      });
    });
  });

  app.get('/getDropdownData', (req, res) => {
    con.query('SELECT id,issue FROM issue_type', (error, results) => {
      if (error) throw error;
      res.json(results);
    });
  });

  app.get('/getTableData/:selectedValue', (req, res) => {
    const selectedTable = req.params.selectedValue;
    console.log('selected Value',selectedTable)
    const sql=`SELECT root_id, issues FROM issue_table WHERE root_id = (Select id from issue_type where issue = ?);`
    con.query(sql, [selectedTable], (error, results) => {
        if (error) throw error;
    res.json(results);
    console.log(results)
  });
  });

  app.get('/yourServerEndpoint/:matchedValue', (req, res) => {
    const matchedValue = req.params.matchedValue;
    console.log('selected Value',matchedValue)
    const sql=`SELECT * FROM ${matchedValue}`;
    con.query(sql, (error, results) => {
        if (error) {
                    if (error.code === 'ER_NO_SUCH_TABLE') {
                      // Handle the 'ER_NO_SUCH_TABLE' error
                      return res.status(500).json({
                        error: 'Table not found',
                        message: 'The requested table does not exist.',
                      });
                    } else {
                      // Handle other errors
                      console.error('Database error:', error);
                      return res.status(500).json({
                        error: 'Internal Server Error',
                        message: 'An unexpected error occurred on the server.',
                      });
                    }
                  }
              
                  // Send the successful response with the data
                  res.json(results);
                
    console.log(results)
  });
  });

  app.listen(4000, () => {
    console.log("Running backend server on port 4000");
  })


  app.get('/fetchRemarks/:currentRowId', (req, res) => {
    
    const  currentRowId  = req.params.currentRowId
    console.log('current row when selected yes',currentRowId)
   
    const sql = 'SELECT remarks FROM battery_issue WHERE id = ?';
 
    con.query(sql, [currentRowId], (err, result) => {
      if (err) {
        console.error('Error fetching remarks:', err);
        console.log(err)
        res.status(500).json({ error: 'Internal Server Error' });
      } else {
        console.log(result[0].remarks)
        res.json(result[0].remarks); // Assuming you expect a single row and column
      }
    });
  });

  app.get('/fetchNextRow/:nextRowId', (req, res) => {
    console.log('Params:', req.params); 
    const  rowId  = req.params.nextRowId
    console.log('next row id from front when selected no:',rowId)
    // const sql = 'SELECT * FROM battery_issue WHERE id > ? ORDER BY id LIMIT 1';
    const sql = 'SELECT * FROM battery_issue WHERE id = ?';
  
    con.query(sql, [rowId], (err, result) => {
      if (err) {
        console.error('Error fetching next row:', err);
        console.log(err)
        res.status(500).json({ error: 'Internal Server Error' });
      } else {
        console.log(result)
        res.json(result[0]); // Assuming you expect a single row
      }
    });
  });
  

//   app.get('/api/getTableData/:selectedValue', (req, res) => {
//     const selectedTable = req.params.selectedValue;
//     const query = `SELECT id, name FROM ${selectedTable}`;
  
//     connection.query(query, (error, results) => {
//       if (error) {
//         if (error.code === 'ER_NO_SUCH_TABLE') {
//           // Handle the 'ER_NO_SUCH_TABLE' error
//           return res.status(500).json({
//             error: 'Table not found',
//             message: 'The requested table does not exist.',
//           });
//         } else {
//           // Handle other errors
//           console.error('Database error:', error);
//           return res.status(500).json({
//             error: 'Internal Server Error',
//             message: 'An unexpected error occurred on the server.',
//           });
//         }
//       }
  
//       // Send the successful response with the data
//       res.json(results);
//     });
//   });