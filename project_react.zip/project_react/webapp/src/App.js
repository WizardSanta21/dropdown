import Login from './page/login'
import Signup from './page/signup';
// import test from './test';
import { Route, Routes } from 'react-router-dom';
import { AuthProvider } from './page/AuthContext'; // Assuming you have an AuthContext
import Testadmin from './page/testadmin';
import Testuser from './page/testuser';
import PrivateRoute from './page/PrivateRoute'; // Import the PrivateRoute component


function App() {
  return (
    <AuthProvider>
    <div className="App">
        <Routes>
          <Route exact path="/" element={<Login />} />
          <Route exact path="/page/signup" element={<Signup />} />
          <Route
            exact
            path="/page/testadmin"
            element={<PrivateRoute element={Testadmin} />}
          />
          <Route
            exact
            path="/page/testuser"
            element={<PrivateRoute element={Testuser} />}
          />
          </Routes>
      
    </div>
    </AuthProvider>
  );
}

export default App;
