import React from 'react'

function Testadmin() {
  return (
    <div>
      <h1>ADMIN</h1>
    </div>
  )
}

export default Testadmin
