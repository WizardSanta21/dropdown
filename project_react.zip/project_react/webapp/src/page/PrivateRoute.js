////////////////////////////////////////////////////// PrivateRoute.js
import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from './AuthContext'; // Assuming you have an AuthContext

const PrivateRoute = ({ element: Element, ...rest }) => {
  const { isAuthenticated } = useAuth(); // Get the authentication state from context
  // const isLoggedIn = localStorage.getItem('isLoggedIn');

  console.log('isAuthenticated Private Route:', isAuthenticated);
  // console.log('isLoggedIn Private Route:', isLoggedsIn)
  console.log('Element : ',Element);
  console.log('Rest : ',rest);

  
  return  isAuthenticated ? (

    <Element/>
    // <Routes>
    // <Route {...rest} element={<Element />} />
    // </Routes>
    //the upper comment method is wrong to render a private route , right method is just to call the <component/> or <element/>
  ) : (
    <Navigate to="/" /> // Redirect to login if not authenticated
  );
};

export default PrivateRoute;
