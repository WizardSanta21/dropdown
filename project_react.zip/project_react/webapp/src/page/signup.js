import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
// import './signup.css'


function Signup() {
  
    const [emp_name, setEmpName] = useState("");
    const [emp_code, setEmpCode] = useState("");
    const [passw, setPassword] = useState("");
    const [cpassw, setConPass] = useState("");
    const navigate = useNavigate();

    const validatePassword = () => {
      const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{9,}$/;
      return regex.test(passw);
    }


    const register = (e) => {
      e.preventDefault();

      // Basic validation
      if (!emp_name) {
        alert("Please enter Employee Name");
        return;
      }

      // Additional check for employee name as text
      if (!/^[A-Za-z\s]+$/.test(emp_name)) {
        alert("Employee Name must contain only letters and spaces");
        return;
      }

      if (!emp_code) {
        alert("Please enter Employee Code");
        return;
      }

      // Additional check for employee code as number
      if (!/^\d+$/.test(emp_code)) {
        alert("Employee Code must be a number");
        return;
      }



      if (!passw) {
        alert("Please enter Password");
        return;
      }

      if (!validatePassword()) {
        alert("Password must contain at least one lowercase letter, one uppercase letter, one numeric digit, one special character, and be at least 9 characters long.");
        return;
      }

      if (!cpassw) {
        alert("Please enter Confirm Password");
        return;
      }

      // Check if passwords match
      if (passw !== cpassw) {
        alert("Passwords do not match");
        return;
      }

      //Axios is used to response a http request 
      Axios.post("http://localhost:4000/page/signup", { emp_name, emp_code, passw, cpassw })
        .then((response) => {

          if (response.data.message === 'Duplicate entry detected') {
            console.log('Duplicate entry detected');
            toast.error('Duplicate entry detected');
          } else {
            console.log('Signup value process Success');
            toast.success('Signup Succesfully');
            navigate('/');
          }
          console.log(response)
        })
        .catch((err) => {
          console.log(err)
        });

    }
    return (
      <div>
        <section>
          <form onSubmit={register}>


            <div className="signin">

              <div className="content">

                <h2>Sign Up</h2>

                <div className="form">

                  <div className="inputBox1sg">
                    <label htmlFor="emp_name"></label>
                    <input
                      type="text"
                      name="emp_name"
                      onChange={(e) => { setEmpName(e.target.value) }}
                      required
                      placeholder="Employee Name" />
                  </div>

                  <div className="inputBox1sg">
                    <label htmlFor="emp_code"></label>
                    <input
                      type="text" n
                      ame="emp_code"
                      onChange={(e) => { setEmpCode(e.target.value) }}
                      required
                      placeholder="Employee Code" />
                  </div>

                  <div className="inputBox1sg">
                    <label htmlFor="passw"></label>
                    <input
                      type="password"
                      name="pass"
                      onChange={(e) => { setPassword(e.target.value) }}
                      required
                      placeholder="Password" />
                  </div>

                  <div className="inputBox1sg">
                    <label htmlFor="cpassw"></label>
                    <input
                      type="password"
                      name="cpassw"
                      onChange={(e) => { setConPass(e.target.value) }}
                      required
                      placeholder="Confirm Password" />
                  </div>

                  <div className="links">  <Link to="/" >Login</Link>
                    {/* <Link to="#">Forgot Password</Link> */}
                  </div>

                  <div className="sig">

                    <button onClick={register}>Sign Up</button>

                  </div>

                </div>
              </div>
            </div>
          </form>
        </section>
        <ToastContainer />

      </div>
    );
  }

export default Signup;
