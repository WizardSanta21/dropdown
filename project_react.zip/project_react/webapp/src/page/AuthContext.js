/////////////////////////////////////////AuthContext.js//////////////////////////////////////////
import React, { createContext, useContext, useState, useEffect } from 'react';
import Cookies from 'js-cookie';


// Create an AuthContext to hold the authentication state and functions
const AuthContext = createContext();

// Create an AuthProvider component to wrap your app with
export function AuthProvider({ children }) {
//   const [isAuthenticated, setIsAuthenticated] = useState(false);
const [isAuthenticated, setIsAuthenticated] = useState(
    sessionStorage.getItem('isAuthenticated') === 'true'
  );
  console.log('isAuthenticated Auth Context:', isAuthenticated);

  useEffect(() => {
    // Check if there's a session cookie and set isAuthenticated accordingly
    // const sessionCookie = Cookies.get('session');
    // if (sessionCookie) {
    //   setIsAuthenticated(true);
    // }
    sessionStorage.setItem('isAuthenticated', isAuthenticated);
  }, [isAuthenticated]);

  // Function to log the user in
  const login = () => {
    console.log('Logged IN')
    setIsAuthenticated(true);
    Cookies.set('session', 'authenticated'); // Set a session cookie upon successful login
    console.log('Logged IN 22222')
  };

  // Function to log the user out
  const logout = () => {
    setIsAuthenticated(false);
    Cookies.remove('session'); // Remove the session cookie upon logout
  };

  // Pass the context value down to its children
  const contextValue = {
    isAuthenticated,
    login,
    
    logout,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
}

// A custom hook to access the AuthContext values
export function useAuth() {
  return useContext(
    AuthContext);
}
