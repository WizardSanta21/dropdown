
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// function Testuser() {
//     const [data, setData] = useState([]);
//   const [selectedValue, setSelectedValue] = useState('');
//   const [tableData, setTableData] = useState([]);
//   const [selectedTableValue, setSelectedTableValue] = useState('');
//   const [selectedOption,setSelectedOption]=useState('');
//   const [serverResponseData, setServerResponseData] = useState([]);
//   const [showAdditionalTable, setShowAdditionalTable] = useState(false);

//   useEffect(() => {
//     // Fetch data from MySQL database
//     axios.get('http://localhost:4000/getDropdownData')
//       .then(response => setData(response.data))
//       .catch(error => console.error('Error fetching data:', error));
//   }, []);

//   useEffect(() => {
//     // Fetch data for the second dropdown based on the selected value from the first dropdown
//     if (selectedValue) {
//       axios.get(`http://localhost:4000/getTableData/${selectedValue}`)
//         .then(response => setTableData(response.data))
//         .catch(error => console.error('Error fetching table data:', error));
//     }
//   }, [selectedValue]);

//   const handleDropdownChange = (event) => {
//     setSelectedValue(event.target.value);
//     setSelectedTableValue(''); // Reset the second dropdown when the first dropdown changes
//     setSelectedOption('')
//     // const selectedOption = data.find(item => item.issue === event.target.value);

//     // if (selectedOption) {
//     //   setSelectedValue(selectedOption.issue);
//     //   setSelectedTableValue(selectedOption.id); // Use the id value from the selected option
//     // } else {
//     //   setSelectedValue('');
//     //   setSelectedTableValue('');
//     // }
//   };

//   const handleTableDropdownChange = (event) => {
//     // setSelectedTableValue(event.target.value);

//     const normalizedValue = normalizeString(event.target.value);
//     setSelectedTableValue(normalizedValue);
//     console.log('Selected Table Value:', event.target.value);

//     // Compare normalizedValue with a list of values
//     const listOfValuesToCompare = ['adaptor_charger_powerpack_issue', 'alert_erruption','battery_issue'];

//     // Check if normalizedValue is in the list
//     if (listOfValuesToCompare.includes(normalizedValue)) {
//       // Perform the server query with the matched value
//       performServerQuery(normalizedValue);
//     } else {
//       console.log('Selected value does not match the list.');
//       // Handle accordingly (e.g., show an error message)
//     }



//   };

//   const performServerQuery = (matchedValue) => {
//     // Your server query logic goes here
//     // Use the matchedValue in your query
//     axios.get(`http://localhost:4000/yourServerEndpoint/${matchedValue}`)
//       .then(response => {
//         // Handle the response from the server
//         setServerResponseData(response.data);
//         console.log('Server query response:', response.data);
//       })
//       .catch(error => console.error('Error in server query:', error));
//   };

//   // Function to normalize a string by converting to lowercase and replacing underscores
//   const normalizeString = (str) => {
//     return str.toLowerCase().replace(/[ /]/g, '_');
//   };

//   const handleShowNextRow = (index) => {
//     // Handle the logic to show the next row based on the index
//     // You may need to implement your own logic here
//     console.log('Show next row for index:', index);

//     // // If "Yes" is selected, set showAdditionalTable to true
//     // if (index === 0 && selectedTableValue === 'Yes') {
//     //   setShowAdditionalTable(true);
//     // }
//     console.log('value for',selectedOption)
//     // If "No" is selected, set showAdditionalTable to true for the current row
//     if (index >= 0 && (selectedOption === 'Yes' || selectedOption === 'No')) {
//         // If "No" is selected, set showAdditionalTable to true for the next row
//         console.log('yyyyyy')
//         if (selectedOption === 'No' && index < serverResponseData.length - 1) {
//             if (index < serverResponseData.length - 1) {
//                 handleTableDropdownChange({ target: { value: serverResponseData[index + 1].issues } });
//               }
//         } else {
//           // If "Yes" is selected or if it's the last row, set showAdditionalTable to false
//           setShowAdditionalTable(false);
//         //   setSelectedTableValue(''); // Reset selectedTableValue when "Yes" is selected
//         }
//       }
//   };


//   return (
//     <div>
//       <label>Select an option:</label>
//       <select onChange={handleDropdownChange} value={selectedValue}>
//         <option value="">-- Select --</option>
//         {data.map(item => (
//           <option key={item.id} value={item.issue}>
//             {item.issue}
//           </option>
//         ))}
//       </select>

//       {selectedValue && ( 
//       <div>
//           <label>Select an item from the table:</label>
//           <select onChange={handleTableDropdownChange} value={selectedTableValue}>
//             <option value="">-- Select --</option>
//             {tableData.map(row => (
//               <option key={row.root_id} value={row.issues}>
//                 {row.issues}
//               </option>
//             ))}
//           </select>

//           {selectedTableValue && (
//              <div>
//              <p>You selected: {selectedTableValue}</p>

//              {serverResponseData.length > 0 && (
//                <table>
//                  <thead>
//                    <tr>
//                      {/* Add table header based on your server response data */}
//                      <th>Steps</th>
//                      <th>Diagnosis</th>
//                      <th>Remarks</th>
//                      {/* Add more columns as needed */}
//                    </tr>
//                  </thead>
//                  <tbody>
//                    {/* Map over server response data to render rows */}
//                    {serverResponseData.map((row,index) => (
//                      <tr key={row.root_id} style={{ display: index === 0 || (showAdditionalTable && index === 0) ? 'table-row' : 'none' }}>
//                        <td>{row.steps}</td>
//                        <td>{row.diagnosis}</td>
//                        <td>{row.remarks}</td>
//                        <td>
//                         (
//                             <select onChange={(e) => {handleShowNextRow(); setSelectedOption(e.target.value);} }>
//                               <option value="">Select</option>
//                               <option value="Yes">Yes</option>
//                               <option value="No">No</option>
//                             </select>
//                             ) : (
//                                 <div>
//                                 {selectedOption === 'Yes' ? (
//                                   <p>{row.remarks}</p>
//                                 ) : (
//                                 //   Render the dropdown for "No" selection
//                                 //   <select onChange={(e) => {handleShowNextRow(); setSelectedOption(e.target.value);} }>
//                                 //     <option value="">Select</option>
//                                 //     <option value="Yes">Yes</option>
//                                 //     <option value="No">No</option>
//                                 //   </select>

//                                     <tr>
//                     <td>{serverResponseData[serverResponseData.length - 1].steps}</td>
//                     <td>{serverResponseData[serverResponseData.length - 1].diagnosis}</td>
//                     <td>{serverResponseData[serverResponseData.length - 1].remarks}</td>
//                     <td><select onChange={(e) => {handleShowNextRow(); setSelectedOption(e.target.value);} }>
//                                 //     <option value="">Select</option>
//                                 //     <option value="Yes">Yes</option>
//                                 //     <option value="No">No</option>
//                                 //   </select></td>
//                     {/* Add more columns as needed */}
//                   </tr>


//                                 )}
//                               </div>
//                           )
//                         </td>
//                        {/* Add more columns as needed */}
//                      </tr>
//                    ))}
//                    {/* Display rest of the rows one by one after "No" option is selected */}
//                   {showAdditionalTable && (
//                     // serverResponseData.slice(1).map((row, rowIndex) => (
//                     //   <tr key={row.root_id}>
//                     //     <td>{row.steps}</td>
//                     //     <td>{row.diagnosis}</td>
//                     //     <td>{row.remarks}</td>
//                     //     {/* Add more columns as needed */}
//                     //   </tr>
//                     // ))
//                     <tr>
//                     <td>{serverResponseData[serverResponseData.length - 1].steps}</td>
//                     <td>{serverResponseData[serverResponseData.length - 1].diagnosis}</td>
//                     <td>{serverResponseData[serverResponseData.length - 1].remarks}</td>
//                     {/* Add more columns as needed */}
//                   </tr>
//                   )}
//                  </tbody>
//                </table>
//              )}
//              {/* Display static value for non-FCR
//             {showAdditionalTable && (
//               <div>
//                 <p>Static Value for Non-FCR</p>
//               </div>
//             )} */}
//            </div>
//           )}
//         </div>
//       )}
//     </div>
//   );
// }

// export default Testuser


import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Testuser() {
    const [data, setData] = useState([]);
    const [selectedValue, setSelectedValue] = useState('');
    const [tableData, setTableData] = useState([]);
    const [selectedTableValue, setSelectedTableValue] = useState('');
    const [selectedOption, setSelectedOption] = useState('');
    const [serverResponseData, setServerResponseData] = useState([]);
    const [serverResponseData1, setServerResponseData1] = useState([]);
    // const [showAdditionalTable, setShowAdditionalTable] = useState(false);
    const [remarks, setRemarks] = useState('');





    console.log('selected option: ', selectedOption)
    console.log('remark: ', remarks)



    useEffect(() => {
        if (selectedValue) {
            axios.get(`http://localhost:4000/getTableData/${selectedValue}`)
                .then(response => setTableData(response.data))
                .catch(error => console.error('Error fetching table data:', error));
        }
    }, [selectedValue]);

    const handleDropdownChange = (event) => {
        setSelectedValue(event.target.value);
        setSelectedTableValue('');
        // setSelectedOption('');
        // setServerResponseData([]);
    };

    const handleTableDropdownChange = (event) => {
        const normalizedValue = normalizeString(event.target.value);
        setSelectedTableValue(normalizedValue);

        const listOfValuesToCompare = ['adaptor_charger_powerpack_issue', 'alert_erruption', 'battery_issue'];

        if (listOfValuesToCompare.includes(normalizedValue)) {
            performServerQuery(normalizedValue);
        } else {
            // setServerResponseData([]);
            console.log('Selected value does not match the list.');
        }
    };

    const performServerQuery = (matchedValue) => {
        axios.get(`http://localhost:4000/yourServerEndpoint/${matchedValue}`)
            .then(response => setServerResponseData([...serverResponseData, ...response.data]))
            .catch(error => console.error('Error in server query:', error));
    };

    const normalizeString = (str) => {
        return str.toLowerCase().replace(/[ /]/g, '_');
    };


    useEffect(() => {
        console.log('Updated serverResponseData:', serverResponseData);
      }, [serverResponseData]);

      const removeDuplicates = (data) => {
        const uniqueData = [];
        const ids = new Set();

        for (const item of data) {
          if (!ids.has(item.id)) {
            ids.add(item.id);
            uniqueData.push(item);
          }
        }

        return uniqueData;
      };

      const serverResponseData11 = removeDuplicates(serverResponseData1);

    const handleShowNextRow = (e, index) => {

        console.log('Handling show next row for index:', index, 'Selected option:', e.target.value);

        // if (index >= 0 && (selectedOption === 'Yes' || selectedOption === 'No')) {
        if (index >= 0) {
            // if (selectedOption === 'No' && index < serverResponseData.length - 1) {
            if (e.target.value === 'No') {
                console.log('Fetching entire data for the next row');
                console.log('serverResponseData', serverResponseData)
                const nextRowId = serverResponseData[index + 1].id;
                console.log('nextRowId', nextRowId)

                axios.get(`http://localhost:4000/fetchNextRow/${nextRowId}`)
                    .then(response => {
                        console.log('Next row data from server:', response.data);
                        // setServerResponseData(response.data);
                        // console.log('issue value', response.data.name)
                        // const normalizedValue = normalizeString(response.data.name);
                        // setSelectedTableValue(normalizedValue);
                        // handleTableDropdownChange(response.data.name)
                        // console.log('issue value222', normalizedValue)

                        setServerResponseData1([...serverResponseData11, { ...response.data, selectedOption }]);
                        // setSelectedOption('No'); 
                        // setShowAdditionalTable(true);
                        // console.log('det', det)
                    })
                    .catch(error => console.error('Error fetching next row:', error));
            } else if (e.target.value === 'Yes') {
                console.log('Fetching remarks for the current row');
                const currentRowId = serverResponseData[index].id;
                console.log('currentRowId', currentRowId)
               

                axios.get(`http://localhost:4000/fetchRemarks/${currentRowId}`)
                    .then(response => {
                        console.log('Remarks for the current row:', response.data);
                        // Assuming you have a state variable to hold remarks
                        setRemarks(response.data.remarks);
                        // setServerResponseData1([...serverResponseData1, { ...response.data, selectedOption }]);
                        // setServerResponseData1([...serverResponseData1, { ...serverResponseData[index], selectedOption: 'No' }]);
                    })
                    .catch(error => console.error('Error fetching remarks:', error));

            } else {

            }
        }
    };

    useEffect(() => {
        axios.get('http://localhost:4000/getDropdownData')
            .then(response => setData(response.data))
            .catch(error => console.error('Error fetching data:', error));
    }, []);

    console.log('serverResponseData1 value',serverResponseData11)


    return (
        <div>
            <label>Select an option:</label>
            <select onChange={handleDropdownChange} value={selectedValue}>
                <option value="">-- Select --</option>
                {data.map(item => (
                    <option key={item.id} value={item.issue}>
                        {item.issue}
                    </option>
                ))}
            </select>

            {selectedValue && (
                <div>
                    <label>Select an item from the table:</label>
                    <select onChange={handleTableDropdownChange} value={selectedTableValue}>
                        <option value="">-- Select --</option>
                        {tableData.map(row => (
                            <option key={row.root_id} value={row.issues}>
                                {row.issues}
                            </option>
                        ))}
                    </select>

                    {selectedTableValue && (
                        <div>
                            <p>You selected: {selectedTableValue}</p>

                            {serverResponseData.length > 0 && (
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Steps</th>
                                            <th>Diagnosis</th>
                                            <th>Remarks</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {serverResponseData.map((row, index) => (
                                            <React.Fragment key={row.id}>

                                                <tr style={{ display: index === 0 ? 'table-row' : 'none' }}>
                                                    <td>{row.steps}</td>
                                                    <td>{row.diagnosis}</td>
                                                    <td>{row.remarks}</td>
                                                    <td>
                                                        {index < serverResponseData.length - 1 && (
                                                            <select onChange={(e) => {
                                                                setSelectedOption(e.target.value);
                                                                console.log('Selected option inside onchange:', e.target.value);
                                                                handleShowNextRow(e, index);
                                                            }}
                                                                value={selectedOption}

                                                            >
                                                                <option value="1">Select</option>
                                                                <option value="Yes">Yes</option>
                                                                <option value="No">No</option>
                                                            </select>
                                                        )}
                                                    </td>

                                                </tr>
                                                
                                                
                                                {selectedOption === 'No' && serverResponseData11[index] && (
                                                   
                                                   <tr >
                                                        <td>{serverResponseData11[index].steps}</td>
                                                        <td>{serverResponseData11[index].diagnosis}</td>
                                                        <td>{serverResponseData11[index].remarks} </td>
                                                        <td>
                                                            <select onChange={(e) => { handleShowNextRow(e, index + 1); setSelectedOption(e.target.value); }}>
                                                                <option value="1">Select</option>
                                                                <option value="Yes">Yes</option>
                                                                <option value="No">No</option>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                    
                                                    

                                                    
                                                   
                                                )}
                                                
                                                {index === serverResponseData11.length  && selectedOption === 'Yes' && (
                                                   
                                                   
                                                   
                                                   <tr>
                                                        <td colSpan="2">Remarks: {remarks}</td>
                                                        <td></td>
                                                    </tr>
                                                    
                                                )}                       
                                                

{/* {((selectedOption === 'No' && serverResponseData11[index]) ||  (index === serverResponseData11.length && selectedOption === 'Yes')) && (
    <>
        {selectedOption === 'No' && serverResponseData11[index] && (
            <>
                <td>{serverResponseData11[index].steps}</td>
                <td>{serverResponseData11[index].diagnosis}</td>
                <td>{serverResponseData11[index].remarks}</td>
                <td>
                    <select onChange={(e) => { handleShowNextRow(e, index + 1); setSelectedOption(e.target.value); }}>
                        <option value="1">Select</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </td>
            </>
        )}
        {index === serverResponseData11.length && selectedOption === 'Yes' && (
            <>
                <td colSpan="2">Remarks: {remarks}</td>
                <td></td>
            </>
        )}
    </>
)} */}


                                            </React.Fragment>
                                        ))}
                                    </tbody>
                                </table>
                            )}

                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

export default Testuser;
