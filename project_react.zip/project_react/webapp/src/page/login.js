import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
// import './login.css'
import { useAuth } from './AuthContext';

function Login() {
  const { login } = useAuth(); // Access isAuthenticated and login function from the context
    const [emp_code1, setEmpCode] = useState("");
    const [passw1, setPassword] = useState("");
    const navigate = useNavigate();

    
    let logged = (e) => {
      e.preventDefault();
      if (!emp_code1) {
        alert("Please enter Employee Code");
        return;
      }

      if (!/^\d+$/.test(emp_code1)) {
        alert("Employee Code must be a number");
        return;
      }

      if (!passw1) {
        alert("Please enter Password");
        return;
      }

      Axios.post("http://localhost:4000/", { emp_code1, passw1 })
        .then((response) => {
          console.log(response.data);
          // const { message, userInfo } = response.data;
          if (response.data.message === 'Wrong password') {
            console.log('Wrong password');
            toast.error('Wrong password');
          }
          if (response.data.message === 'Login success') {
            console.log('Login successfully');
            toast.success('Login successfully');
            setEmpCode(emp_code1);
            // setEmpName(response.data.userInfo.Employee_Name);
            // navigate(`/pages/dash/${emp_code1}`); // Navigate to the user profile page with empCode as a parameter
            // navigate(`/pages/home/${emp_code1}`);
            // login(); // Call the login function from the context
            const role = response.data.role;

            if (role === 'admin') {
              console.log(role)
              navigate(`/page/testadmin`);
            } else if (role === 'user') {
              navigate(`/page/testuser`);
            } else {
              // Handle unknown roles here
            }
          }
          if (response.data.message === 'User not found') {
            console.log('User not found');
            toast.error('User not found');
          }

          console.log(response)
          login();
          // localStorage.setItem('isLoggedIn', 'true');

        })
        .catch((err) => {
          console.log(err)
        });
      }
  return (
    <div>
      <h1>Login Page</h1>
      <section>
          <form onSubmit={logged}>

            <div className="login">

              <div className="content">

                <h2>Log In</h2>

                <div className="form">

                  <div className="inputBox1lg">
                    <label htmlFor="emp_code1"></label>
                    <input type="text" name="emp_code1"
                      onChange={(e) => { setEmpCode(e.target.value) }}
                      required placeholder="Employee Code" />

                  </div>

                  <div className="inputBox1lg">
                    <label htmlFor="passw1"></label>
                    <input type="password" name="passw1"
                      onChange={(e) => { setPassword(e.target.value) }}
                      required placeholder="Password" />
                      <br />
                    <br />
                    <div className="links">  <Link to="/page/signup" >SignUp</Link>
                      {/* <Link to="/#">Forgot Password</Link> */}
                    </div>
                    <br />
                    <div className="log">
                      <button onClick={logged}>Log In</button>

                      {/* <button><Link to="/pages/home" >Log In</Link></button> */}
                    </div>

                  </div>

                </div>

              </div>
            </div>
          </form>

        </section>
        <ToastContainer />
    </div>
  );
}

export default Login
